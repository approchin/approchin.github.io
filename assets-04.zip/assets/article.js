(() => {
  if (window.renderMathInElement) {
    for (const expression of document.querySelectorAll(".arithmatex")) {
      window.renderMathInElement(expression, {
        delimiters: [
          { left: "\\[", right: "\\]", display: true },
          { left: "\\(", right: "\\)", display: false },
        ],
        throwOnError: false,
        trust: false,
      });
    }
  }

  const screen = document.querySelector("#screen");
  const picker = document.querySelector("#clip-picker");
  const currentTitle = document.querySelector("#clip-title");
  const currentMetrics = document.querySelector("#clip-metrics");
  const clipLinks = [...picker.querySelectorAll("a[data-clip-id]")];
  const variantButtons = [...document.querySelectorAll("button[data-variant]")];
  const playerLabel = document.querySelector("#policy-label");
  const playChip = document.querySelector("#play-clip .play-chip").cloneNode(true);
  const width = Number(screen.dataset.frameWidth);
  const height = Number(screen.dataset.frameHeight);
  let current = clipLinks.find(link => link.getAttribute("aria-current") === "true");
  let variant = "a";

  function play(url, poster, title) {
    const previous = screen.querySelector("video");
    if (previous) previous.pause();
    const label = title + "，左侧参考动作，右侧" + playerLabel.textContent;
    const video = document.createElement("video");
    video.width = width;
    video.height = height;
    video.controls = true;
    video.playsInline = true;
    video.poster = poster;
    video.src = url;
    video.setAttribute("aria-label", label);

    video.addEventListener("error", () => {
      const fallback = document.createElement("a");
      fallback.className = "screen-poster";
      fallback.href = url;
      fallback.setAttribute("aria-label", "打开" + title + " MP4");
      const thumb = document.createElement("img");
      thumb.src = poster;
      thumb.alt = label;
      const action = document.createElement("span");
      action.className = "play-chip";
      action.textContent = "打开 MP4";
      fallback.append(thumb, action);
      screen.replaceChildren(fallback);
      fallback.focus({ preventScroll: true });
    }, { once: true });

    screen.replaceChildren(video);
    video.focus({ preventScroll: true });
    video.play().catch(() => { /* Native controls remain available. */ });
  }

  function plainClick(event) {
    return event.button === 0 && !event.metaKey && !event.ctrlKey &&
      !event.shiftKey && !event.altKey && !event.defaultPrevented;
  }

  function selectedClip() {
    const alt = variant === "b";
    return {
      title: current.dataset.title,
      url: alt ? current.dataset.videoB : current.dataset.videoA || current.href,
      poster: alt ? current.dataset.posterB : current.dataset.poster,
    };
  }

  function restorePoster() {
    const playback = screen.querySelector("video");
    if (playback) playback.pause();
    const clip = selectedClip();
    const label = clip.title + "，左侧参考动作，右侧" + playerLabel.textContent;
    const link = document.createElement("a");
    link.id = "play-clip";
    link.className = "screen-poster";
    link.href = clip.url;
    link.setAttribute("aria-label", "播放" + label);
    const poster = document.createElement("img");
    poster.src = clip.poster;
    poster.alt = label;
    poster.width = width;
    poster.height = height;
    link.append(poster, playChip.cloneNode(true));
    screen.replaceChildren(link);
  }

  screen.addEventListener("click", event => {
    const playLink = event.target.closest("#play-clip");
    if (!playLink || !plainClick(event)) return;
    event.preventDefault();
    const clip = selectedClip();
    play(clip.url, clip.poster, clip.title);
  });

  for (const link of clipLinks) {
    link.addEventListener("click", event => {
      if (!plainClick(event)) return;
      event.preventDefault();
      for (const sibling of clipLinks) sibling.removeAttribute("aria-current");
      link.setAttribute("aria-current", "true");
      current = link;
      currentTitle.textContent = link.dataset.title;
      currentMetrics.textContent = link.dataset.metric;
      picker.open = false;
      const rect = screen.getBoundingClientRect();
      if (rect.top < 0 || rect.bottom > innerHeight) screen.scrollIntoView({ block: "nearest" });
      const clip = selectedClip();
      play(clip.url, clip.poster, clip.title);
    });
  }

  for (const button of variantButtons) {
    button.addEventListener("click", () => {
      if (button.dataset.variant === variant) return;
      variant = button.dataset.variant;
      for (const control of variantButtons) {
        control.setAttribute("aria-pressed", String(control === button));
      }
      playerLabel.textContent = "策略 " + variant.toUpperCase() + " 轨迹";
      for (const link of clipLinks) {
        link.href = variant === "b" ? link.dataset.videoB : link.dataset.videoA;
      }
      restorePoster();
    });
  }

  const toc = [...document.querySelectorAll(".article-nav a")];
  const headings = toc.map(link => document.getElementById(link.hash.slice(1)));
  let scheduled = false;
  function markLocation() {
    let i = 0;
    headings.forEach((section, j) => {
      if (section.getBoundingClientRect().top <= 125) i = j;
    });
    if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 3) {
      i = headings.length - 1;
    }
    toc.forEach((link, j) => {
      if (i === j) {
        if (link.getAttribute("aria-current") !== "location") link.setAttribute("aria-current", "location");
      } else {
        link.removeAttribute("aria-current");
      }
    });
    scheduled = false;
  }
  window.addEventListener("scroll", () => {
    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(markLocation);
    }
  }, { passive: true });
  markLocation();
})();
