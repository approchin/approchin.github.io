"""Run fixed-checkpoint ARDY G1 path-only replan and startup experiments."""
import argparse
import json
import os
from pathlib import Path
import tempfile
import time
from types import SimpleNamespace

import numpy as np
import torch

from ardy.constraints import FullBodyConstraintSet, Root2DConstraintSet
from ardy.data_processing.skeleton import load_csv_g1_animation
from ardy.exports.mujoco import MujocoQposConverter
from ardy.model.load_model import load_model
from buffer_r3 import MODES, path_for, stream


ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / "r3-config.json").read_text())
RESULTS = ROOT / "references"
RESULTS.mkdir(exist_ok=True)


def write_case(name, arrays, metadata):
    path = RESULTS / (name + ".npz")
    tmp = RESULTS / (name + ".tmp.npz")
    np.savez_compressed(tmp, **arrays)
    os.replace(tmp, path)
    tmp = RESULTS / (name + ".tmp.json")
    tmp.write_text(json.dumps(metadata, indent=2, allow_nan=False))
    os.replace(tmp, RESULTS / (name + ".json"))
    print("CASE", name, "frames", len(next(iter(arrays.values()))), flush=True)


class Ardy:
    def __init__(self, key):
        self.spec = CFG[key]
        local = Path((ROOT / (key.upper() + ".path")).read_text().strip())
        weights = ROOT / "weights"
        weights.mkdir(exist_ok=True)
        name = self.spec["model"].split("/")[-1]
        checkpoint = weights / name
        if not checkpoint.exists():
            checkpoint.symlink_to(local, target_is_directory=True)
        if checkpoint.resolve() != local.resolve():
            raise RuntimeError(f"Unexpected local checkpoint: {checkpoint}")
        t0 = time.perf_counter()
        self.model = load_model(name, device="cuda", checkpoints_dir=weights, text_encoder=False)
        self.converter = MujocoQposConverter(self.model.skeleton)
        self.horizon = self.spec["frames"]
        self.feat = torch.zeros((1, 1, 4096), device="cuda")
        self.mask = torch.zeros((1, 1), dtype=torch.bool, device="cuda")
        actual = (self.model.gen_horizon_len, self.model.num_frames_per_token, self.model.motion_rep.fps)
        if actual != (self.horizon, 4, 25):
            raise ValueError(f"Unexpected model contract {actual}")
        torch.cuda.synchronize()
        print("MODEL", name, "load_s", round(time.perf_counter() - t0, 3), flush=True)

    def ground_seed(self):
        neutral = np.asarray(json.loads((ROOT / "grounded-qpos.json").read_text())["qpos"])
        imported = np.repeat(neutral[None], 4, axis=0)
        imported[:, 3:7] = imported[:, [4, 5, 6, 3]]
        names = self.model.skeleton.bone_order_names
        skeleton = SimpleNamespace(bones=names, get_bones_names=lambda: names)
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            path = Path(directory) / "neutral.csv"
            np.savetxt(path, imported, delimiter=",")
            root_cm, local_np = load_csv_g1_animation(path, skeleton, csv_format="retargeted_from_unitree")
        root = torch.as_tensor(root_cm / 100, device="cuda", dtype=torch.float32)
        local = torch.as_tensor(local_np, device="cuda", dtype=torch.float32)
        recovered = self.converter.dict_to_qpos({"local_rot_mats": local, "root_positions": root}, device="cuda")
        delta = np.max(np.abs(recovered[:, 7:] - neutral[7:]))
        qdot = abs(recovered[0, 3:7] @ neutral[3:7])
        if np.max(np.abs(recovered[:, :3] - neutral[:3])) > 1e-5 or 1 - qdot > 1e-5 or delta > 1e-4:
            raise RuntimeError(f"Neutral pose did not round-trip (joint {delta}, quat dot {qdot})")
        with torch.inference_mode():
            motion = self.model.motion_rep(local[None], root[None], to_normalize=True, to_canonicalize=False)
            rotations, joints, _ = self.model.skeleton.fk(local, root)
        if motion.shape != (1, 4, 414):
            raise ValueError(f"Unexpected ground seed representation {motion.shape}")
        print("GROUND_SEED_ROUNDTRIP", float(delta), float(qdot), flush=True)
        return motion[0].float().cpu().numpy(), joints, rotations

    @torch.inference_mode()
    def __call__(self, history, target, keyframe=None):
        start = time.perf_counter()
        h = 0 if history is None else len(history)
        past = torch.as_tensor(history, device="cuda")[None] if h else None
        n = h + len(target)
        waypoints = torch.as_tensor(target[:, ::-1].copy(), dtype=torch.float32, device="cuda")
        constraints = [Root2DConstraintSet(self.model.skeleton, torch.arange(h, n), waypoints)]
        if keyframe is not None:
            joints, rotations = keyframe
            # A support keyframe at the start and two source ticks later.
            offsets = torch.tensor([0, 2], dtype=torch.long)
            jp = joints[:2].clone()
            jp[:, :, 0] += waypoints[offsets, 0:1] - jp[:, :1, 0]
            jp[:, :, 2] += waypoints[offsets, 1:2] - jp[:, :1, 2]
            constraints.append(FullBodyConstraintSet(self.model.skeleton, offsets + h, jp,
                                                     rotations[:2], root_2d=waypoints[offsets]))
        observed, mask = self.model.motion_rep.create_conditions_from_constraints_batched(
            constraints, torch.tensor([n], device="cuda"), to_normalize=True, device="cuda")
        if observed.shape != (1, n, 414) or mask.shape != observed.shape:
            raise ValueError(f"Unexpected condition pair {observed.shape} {mask.shape}")
        torch.cuda.synchronize()
        prepared = time.perf_counter()
        samples = self.model.autoregressive_step(
            num_frames=n, init_history_sequence=past, num_denoising_steps=CFG["denoising_steps"],
            motion_mask=mask, observed_motion=observed, cfg_weight=tuple(CFG["cfg"]),
            text_feat=self.feat, text_pad_mask=self.mask)
        torch.cuda.synchronize()
        denoised = time.perf_counter()
        if samples.shape != (1, h + self.horizon, 414):
            raise ValueError(f"Unexpected output shape {samples.shape}")
        decoded = self.model.motion_rep.inverse(samples, is_normalized=True)
        window = {k: v[:, h:] for k, v in decoded.items() if torch.is_tensor(v) and v.ndim >= 2}
        q = np.asarray(self.converter.dict_to_qpos(window, device="cuda"))[0].astype(np.float32)
        root = window["root_positions"][0].cpu().numpy()
        if np.max(np.abs(q[:, :3] - root[:, [2, 0, 1]])) > 1e-5:
            raise ValueError("Root XYZ/export mismatch")
        if not np.allclose(np.linalg.norm(q[:, 3:7], axis=1), 1, atol=1e-5) or not np.isfinite(q).all():
            raise ValueError("Invalid qpos reference")
        values = {"qpos": q, "motion": samples[0, h:].float().cpu().numpy(),
                  "target": target[:self.horizon], "contacts": window["foot_contacts"][0].bool().cpu().numpy(),
                  "positions": window["posed_joints"][0].float().cpu().numpy(),
                  "local": window["local_rot_mats"][0].float().cpu().numpy()}
        torch.cuda.synchronize()
        end = time.perf_counter()
        values["timing"] = {"condition_ms": (prepared - start) * 1000, "denoise_ms": (denoised - prepared) * 1000,
                            "decode_ms": (end - denoised) * 1000, "wall_ms": (end - start) * 1000}
        return values


def rng(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.cuda.reset_peak_memory_stats()


def online(engine, stage):
    if stage == "smoke":
        test = dict(CFG["trials"]["burst"], ticks=210)
        tests = [("burst", test, "priority", CFG["seeds"][0], False)]
    else:
        tests = [(scenario, trial, mode, seed, False) for scenario, trial in CFG["trials"].items()
                 for seed in CFG["seeds"] for mode in MODES]
        tests += [(scenario, CFG["trials"][scenario], "priority", CFG["seeds"][0], True)
                  for scenario in ("burst", "outage")]
    for scenario, trial, mode, seed, paced in tests:
        name = f"{stage}_{scenario}_{mode}_{seed}" + ("_wall" if paced else "")
        rng(seed)
        poses, ledger = stream(engine, CFG, trial, mode, paced)
        peak = torch.cuda.max_memory_allocated() / 2**20
        if not np.isfinite(poses["preview"]).all():
            raise ValueError("Non-finite reference")
        write_case(name, poses, {"kind": "buffer", "scenario": scenario, "mode": mode, "seed": seed,
                                 "paced": paced, "trial": trial, "ledger": ledger, "peak_allocated_MiB": peak})


def starts(h52):
    h8 = Ardy("h8")
    grounded, key_joints, key_rot = h52.ground_seed()
    points = path_for(np.empty((0, 2)), 0, (0, 0.55, 0), 25 * 8 + 104)
    for seed in CFG["seeds"]:
        for mode in ("h52_cold", "h52_grounded", "h52_grounded_key", "h8", "h8_bootstrap_h52"):
            rng(seed)
            prior = grounded.copy() if mode in ("h52_grounded", "h52_grounded_key") else None
            output = {key: [] for key in ("qpos", "target", "contacts", "positions", "local")}
            log = []
            emitted = 0
            while emitted < 200:
                engine = h8 if mode == "h8" or (mode == "h8_bootstrap_h52" and emitted < 16) else h52
                key = (key_joints, key_rot) if emitted == 0 and mode == "h52_grounded_key" else None
                result = engine(prior, points[emitted:emitted + CFG["path_preview"]], key)
                pred = result["motion"]
                prior = pred if prior is None else np.concatenate((prior, pred))
                prior = prior[-CFG["history"]:]
                take = min(len(pred), 200 - emitted)
                for name in output:
                    output[name].append(result[name][:take])
                log.append({"first_frame_25": emitted, "released": take, "generator_horizon": engine.horizon,
                            **result["timing"]})
                emitted += take
            arrays = {k: np.concatenate(v) for k, v in output.items()}
            arrays["joint_names"] = np.asarray(h52.model.skeleton.bone_order_names)
            write_case(f"start_{mode}_{seed}", arrays,
                       {"kind": "startup", "mode": mode, "seed": seed, "ledger": log,
                        "peak_allocated_MiB": torch.cuda.max_memory_allocated() / 2**20})



def bootstrap_h8(h8, h52, command):
    target = path_for(np.empty((0, 2)), 0, command, CFG["path_preview"] + 16)
    first = h8(None, target[:52])
    second = h8(first["motion"], target[8:60])
    history = np.concatenate((first["motion"], second["motion"]))
    long = h52(history, target[16:68])
    packets = (first, second, long)
    return {**{name: np.concatenate([window[name] for window in packets])
               for name in ("motion", "qpos", "contacts", "target")},
            "timing": {metric: sum(window["timing"][metric] for window in packets)
                       for metric in first["timing"]}}


def extras(h52):
    h8 = Ardy("h8")
    tests = [("short_outage", CFG["extra_trials"]["short_outage"], mode, seed, False, False)
             for seed in CFG["seeds"] for mode in MODES]
    tests.extend((scenario, CFG["trials"][scenario], "priority", seed, False, True)
                 for scenario in ("burst", "outage") for seed in CFG["seeds"])
    tests.append(("outage", CFG["trials"]["outage"], "priority", CFG["seeds"][0], True, True))
    for scenario, case, mode, seed, paced, grounded in tests:
        rng(seed)
        init = (lambda command: bootstrap_h8(h8, h52, command)) if grounded else None
        reference, ledger = stream(h52, CFG, case, mode, paced, init)
        tag = mode + ("_bootstrap" if grounded else "")
        name = f"extra_{scenario}_{tag}_{seed}" + ("_wall" if paced else "")
        write_case(name, reference, {"kind": "buffer", "trial": case, "scenario": scenario, "mode": tag,
                                    "seed": seed, "paced": paced, "ledger": ledger,
                                    "peak_allocated_MiB": torch.cuda.max_memory_allocated() / 2**20,
                                    "startup": "h8_16_then_h52" if grounded else "h52_cold"})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["smoke", "buffer", "starts", "extra"])
    opts = parser.parse_args()
    engine = Ardy("h52")
    # Exclude GPU initialization from per-window generation latency.
    rng(CFG["seeds"][0])
    engine(None, path_for(np.empty((0, 2)), 0, (0, 0.55, 0), 52))
    if opts.stage == "starts":
        starts(engine)
    elif opts.stage == "extra":
        extras(engine)
    else:
        online(engine, opts.stage)


if __name__ == "__main__":
    main()
