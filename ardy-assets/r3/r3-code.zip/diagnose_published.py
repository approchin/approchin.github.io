"""Recheck the earlier public H52 reference against the current floor capsules."""
import io
import json
from pathlib import Path
import zipfile

import numpy as np
from replay_r3 import Feet, SONIC_DEFAULT_QPOS, SonicMjSim, XML, json_out

root = Path(__file__).resolve().parent
sim = SonicMjSim(init_qpos=SONIC_DEFAULT_QPOS, headless=True, xml_path=str(XML))
probe = Feet(sim.mj_model)
loc = root / "prior-references.zip"
with zipfile.ZipFile(loc) as archive:
    names = ["G1_H52_after_boundary.csv", "G1_H52_patch_52lookahead_after_boundary.csv"]
    refs = [np.loadtxt(io.BytesIO(archive.read(name)), delimiter=",") for name in names]
assert refs[0].shape[1] == 36
q0 = refs[0]
lower = np.array([min(probe.reference(p)[0]) for p in q0])
first_normal = int(np.flatnonzero(lower < .05)[0])
neutral = q0[0].copy()
neutral[7:] = SONIC_DEFAULT_QPOS[7:]
unrotated = q0[0].copy()
unrotated[3:7] = [1, 0, 0, 0]
evidence = {"source": "https://approchin.github.io/assets/ardy/representative-trajectories.zip",
            "files": names, "same_first_2s": bool(np.array_equal(refs[0][:50], refs[1][:50])),
            "ref_first_2s_sole_min_median_max_m": [float(x) for x in (min(lower[:50]), np.median(lower[:50]), max(lower[:50]))],
            "ref_first_frame_sites_m": probe.reference(q0[0])[1].tolist(),
            "ref_first_frame_sole_m": probe.reference(q0[0])[0].tolist(),
            "first_lower_sole_below_5cm_s": first_normal / 25,
            "reference_dx_at_below_5cm_m": float(q0[first_normal, 0] - q0[0, 0]),
            "ref_first_pelvis_m": float(q0[0, 2]), "ref_first_knees_rad": q0[0, [10, 16]].tolist(),
            "same_root_neutral_joint_sole_m": probe.reference(neutral)[0].tolist(),
            "same_joints_identity_root_rotation_sole_m": probe.reference(unrotated)[0].tolist()}
json_out(root / "reports" / "prior_h52_geometry.json", evidence)
print(json.dumps(evidence))
