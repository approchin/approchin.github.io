"""H52 reference buffer. Keep separate playback and producer clocks."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import math
import time

import numpy as np

DT = 0.02
SLOTS = 11  # Ten SONIC samples and one extra for causal finite differences.
MODES = ("whole", "periodic", "priority")


def direction(command):
    _, speed, heading = command
    angle = math.radians(heading)
    return np.array([math.cos(angle), math.sin(angle)]) * speed


def path_for(existing, anchor, command, count):
    desired = direction(command)
    base = existing[anchor - 1] if anchor else np.zeros(2)
    if anchor == 0:
        return np.arange(count)[:, None] * desired[None, :] / 25
    k = min(anchor - 1, 3)
    previous = (base - existing[anchor - 1 - k]) * 25 / k if k else desired
    u = np.minimum(np.arange(1, count + 1) / 8, 1.0)
    u = u * u * (3 - 2 * u)
    v = previous + u[:, None] * (desired - previous)
    return base + np.cumsum(v, axis=0) / 25


def sample(q, index):
    left, half = divmod(index, 2)
    if not half:
        return q[left]
    a, b = q[left], q[left + 1]
    middle = (a + b) / 2
    rotation = a[3:7] + b[3:7] * (1 if a[3:7] @ b[3:7] >= 0 else -1)
    middle[3:7] = rotation / np.linalg.norm(rotation)
    return middle


def append_at(before, after, anchor):
    return np.concatenate((before[:anchor], after), axis=0)


def stats(items):
    x = np.asarray(items, dtype=float)
    if not x.size:
        return {"n": 0, "p50": None, "p95": None, "max": None}
    return {"n": len(x), "p50": float(np.median(x)),
            "p95": float(np.percentile(x, 95)), "max": float(max(x))}


@dataclass
class Pending:
    anchor: int
    version: int
    tick: int
    result: object
    ready: int | None
    reason: str


def stream(produce, settings, trial, mode, paced=False, bootstrap=None):
    if mode not in MODES:
        raise ValueError(mode)
    first = trial["commands"][0]
    boot = (produce(None, path_for(np.empty((0, 2)), 0, first, settings["path_preview"]))
            if bootstrap is None else bootstrap(first))
    raw = boot["motion"]
    queue = {name: boot[name].copy() for name in ("qpos", "contacts", "target")}
    ledger = [{"phase": "startup", "made": len(raw), **boot["timing"]}]
    rows = []
    versions = np.zeros(len(raw), dtype=np.int16)
    cancellations = set()
    cursor = 0
    next_period = settings["period_ticks"]
    last_request = 0
    version = 0
    pending = None
    lead = settings["lead_ticks"]
    block_from, block_until = trial.get("blackout", (-2, -1))
    commands = trial["commands"]
    executor = ThreadPoolExecutor(max_workers=1) if paced else None
    wall_start = time.perf_counter()

    def finish(job, tick, blocked):
        if job is None:
            return None
        if executor and not job.result.done():
            return job
        if not executor and tick < job.ready:
            return job
        result = job.result.result() if executor else job.result
        phase = "accepted"
        if blocked:
            phase = "blackout_drop"
        elif mode == "priority" and job.version != version:
            phase = "stale_command"
            cancellations.add(job.version)
        elif job.anchor < cursor // 2 + 1:
            phase = "missed_splice"
        old_depth = len(raw) - job.anchor
        ledger.append({"phase": phase, "started_tick": job.tick, "done_tick": tick,
                       "splice_25": job.anchor, "cursor_50": cursor, "old_tail_25": old_depth,
                       "version": job.version, "made": len(result["qpos"]),
                       "dispatch": job.reason, **result["timing"]})
        return result if phase == "accepted" else phase

    try:
        for tick in range(trial["ticks"]):
            if executor:
                time.sleep(max(0, wall_start + tick * DT - time.perf_counter()))
            actual_tick_s = time.perf_counter() - wall_start
            while version + 1 < len(commands) and commands[version + 1][0] <= tick:
                version += 1
            blocked = block_from <= tick < block_until
            outcome = finish(pending, tick, blocked)
            accepted_anchor = -1
            if isinstance(outcome, dict):
                anchor = pending.anchor
                accepted_anchor = anchor
                raw = append_at(raw, outcome["motion"], anchor)
                for name in queue:
                    queue[name] = append_at(queue[name], outcome[name], anchor)
                versions = append_at(versions, np.full(len(outcome["qpos"]), pending.version), anchor)
                assert len(raw) == len(queue["qpos"]) == len(versions)
            if outcome is not pending and pending is not None:
                measured_ticks = max(1, tick - pending.tick)
                if outcome == "missed_splice":
                    lead = max(lead, measured_ticks + 3)
                if outcome == "blackout_drop" or outcome == "missed_splice":
                    next_period = min(next_period, tick + 1)
                pending = None
            last = 2 * (len(raw) - 1)
            low = last - cursor <= lead + 9
            periodic = mode != "whole" and tick >= next_period
            priority = mode == "priority" and (version != last_request or tick == block_until)
            if pending is None and not blocked and (low or periodic or priority):
                safe = cursor // 2 + 1
                # Prefix frames include already promised interpolation endpoints.
                anchor = len(raw) if mode == "whole" else min(len(raw), max(safe, (cursor + lead + 1) // 2))
                start = anchor - (min(anchor, settings["history"]) // 4 * 4)
                points = path_for(queue["target"], anchor, commands[version], settings["path_preview"])
                reason = "command" if priority else "periodic" if periodic else "low_water"
                history = raw[start:anchor].copy()
                if executor:
                    result = executor.submit(produce, history, points)
                    ready = None
                else:
                    result = produce(history, points)
                    ready = tick + max(1, math.ceil(result["timing"]["wall_ms"] / (DT * 1000)))
                pending = Pending(anchor, version, tick, result, ready, reason)
                last_request = version
                next_period = tick + settings["period_ticks"]
            requested = cursor + np.arange(SLOTS)
            valid = requested <= last
            used = np.minimum(requested, last)
            poses = np.stack([sample(queue["qpos"], int(i)) for i in used])
            track = np.stack([sample_xy(queue["target"], int(i)) for i in used])
            source = int(used[0] // 2)
            # An odd midpoint is still half old plan if the next frame belongs to the new epoch.
            rows.append({"preview": poses, "valid": valid, "target": track[0],
                         "contacts": queue["contacts"][source], "active_version": int(versions[source]),
                         "command_version": version, "motion_tick": int(used[0]),
                         "tail_ticks": last - cursor, "splice_25": accepted_anchor,
                         "wall_s": actual_tick_s, "blocked": blocked})
            if valid[0]:
                cursor += 1
    finally:
        if executor:
            executor.shutdown(wait=True)
    if pending:
        ledger.append({"phase": "past_end", "started_tick": pending.tick, "version": pending.version})
    arrays = {key: np.asarray([row[key] for row in rows]) for key in rows[0]}
    if (np.diff(arrays["motion_tick"]) < 0).any() or (np.diff(arrays["motion_tick"]) > 1).any():
        raise ValueError("Playback phase skipped or rewound")
    if not np.allclose(arrays["preview"][~arrays["valid"]],
                       np.broadcast_to(arrays["preview"][:, -1:], arrays["preview"].shape)[~arrays["valid"]]):
        raise ValueError("Unavailable preview must be held at its last published pose")
    arrays["t"] = np.arange(len(rows)) * DT
    if not paced:
        arrays.pop("wall_s")
    return arrays, ledger


def sample_xy(xy, index):
    left, half = divmod(index, 2)
    return (xy[left] + xy[left + 1]) / 2 if half else xy[left]
