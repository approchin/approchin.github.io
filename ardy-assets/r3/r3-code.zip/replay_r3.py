"""Causal G1/SONIC Low-Latency replay and foot-ground diagnostics."""
import argparse
import csv
import json
from pathlib import Path
import time

import mujoco
import numpy as np

from buffer_r3 import DT, SLOTS, direction, stats
from previous_sonic_replay import Controller, SPECS, XML, encoder_input, resample
from humantracker.eval.backends.sonic import (
    DEFAULT_ANGLES_ISAB, ISAB_TO_MUJ, SONIC_DEFAULT_QPOS, SonicMjSim, SonicObsBuilder, action_to_motor_targets,
)
from humantracker.eval.core.geometry import get_sensor_data
from replay_r2 import FootInstrumentation, yaw

ROOT = Path(__file__).resolve().parent
SPEC = SPECS[1]


def json_out(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(obj, allow_nan=False, indent=2))
    tmp.replace(path)


class Feet(FootInstrumentation):
    def __init__(self, model):
        super().__init__(model)
        self.ankles = [int(model.geom_bodyid[g]) for g in
                       [next(k for k, side in self.collisions.items() if side == i) for i in (0, 1)]]
        self.groups = [np.asarray([k for k, side in self.collisions.items() if side == i]) for i in (0, 1)]
        if any(int(model.geom_type[g]) != int(mujoco.mjtGeom.mjGEOM_CAPSULE) for g in self.collisions):
            raise ValueError("Expected G1 floor capsules")
        if abs(float(model.geom_pos[self.floor, 2])) > 1e-8:
            raise ValueError("Expected ground plane at z=0")

    def reference(self, q):
        self.ref.qpos[:] = q
        mujoco.mj_kinematics(self.model, self.ref)
        clearance = []
        for g in self.groups:
            # Capsule axis is its local +Z. The lower spherical cap sets the sole.
            z = self.ref.geom_xpos[g, 2]
            axis_z = np.abs(self.ref.geom_xmat[g, 8])
            radius, half_len = self.model.geom_size[g, :2].T
            clearance.append(min(z - radius - axis_z * half_len))
        return (np.asarray(clearance), self.ref.site_xpos[self.sites, 2].copy(),
                self.ref.xpos[self.ankles, 2].copy(), self.ref.xpos.copy())

    def neutral(self):
        q = np.asarray(SONIC_DEFAULT_QPOS, dtype=np.float64).copy()
        q[:2] = 0
        q[3:7] = [1., 0., 0., 0.]
        raw = self.reference(q)[0]
        q[2] += 0.002 - min(raw)
        new = self.reference(q)[0]
        assert abs(min(new) - .002) < 1e-9
        return {"qpos": q.tolist(), "raw_clearance_m": raw.tolist(), "adjusted_clearance_m": new.tolist(),
                "target_margin_m": .002, "units": "metres, wxyz, radians"}


def load_50hz(path, sim, feet, variant):
    with np.load(path, allow_pickle=False) as stored:
        data = dict(stored)
    if "preview" in data:
        preview = np.asarray(data["preview"], dtype=np.float64)
        original_xy = preview[0, 0, :2].copy()
        preview[:, :, :2] -= original_xy
        data["target"] = data["target"] - original_xy
        data["preview"] = preview
        return data, 0.
    q25 = data["qpos"].astype(np.float64)
    if variant in {"reference_z", "reference_z_reset"}:
        clearance = np.asarray([feet.reference(q)[0].min() for q in q25])
        adjust = np.maximum(0., clearance - .002)
        # Remove the common vertical gap during the first H52; ease out across 0.4 s.
        t = np.arange(len(q25)) / 25
        u = np.clip((2.48 - t) / .4, 0, 1)
        q25[:, 2] -= adjust * (u * u * (3 - 2 * u))
    q, _ = resample(q25, sim.mj_model)
    target25 = data["target"] - q25[0, :2]
    target = np.stack([np.interp(np.arange(len(q)) * DT, np.arange(len(q25)) / 25, v) for v in target25.T], axis=1)
    wanted = np.arange(len(q))[:, None] + np.arange(SLOTS)
    data.update(preview=q[np.minimum(wanted, len(q) - 1)], valid=wanted < len(q), target=target,
                t=np.arange(len(q)) * DT)
    shift = 0.
    if variant == "reset_only":
        shift = min(0., .002 - feet.reference(q[0])[0].min())
    if variant == "reference_z":
        shift = float(data["qpos"][0, 2] - q[0, 2])
    return data, shift


def finite_difference_speed(xy, span):
    base = np.maximum(0, np.arange(len(xy)) - span)
    dt = np.maximum(DT, (np.arange(len(xy)) - base) * DT)
    return (xy - xy[base]) / dt[:, None]


def first_matching(mask, start, end, sustained=1):
    if end - start < sustained:
        return None
    x = np.convolve(mask[start:end].astype(np.int16), np.ones(sustained, dtype=np.int16), mode="valid")
    found = np.flatnonzero(x == sustained)
    return int(start + found[0]) if len(found) else None


def longest(mask):
    boundaries = np.flatnonzero(np.diff(np.r_[False, mask, False]))
    return int(np.max(boundaries[1::2] - boundaries[::2])) if len(boundaries) else 0


def scheduling(data, actual, meta, limits):
    valid = data["valid"]
    moving = finite_difference_speed(actual[:, :2], 10)
    ref_moving = finite_difference_speed(data["preview"][:, 0, :2], 10)
    issued = meta["trial"]["commands"]
    record = []
    wall = data.get("wall_s", data["t"])
    for i, command in enumerate(issued[1:], start=1):
        begin = command[0]
        if begin >= len(actual):
            break
        end = min(issued[i + 1][0], len(actual)) if i + 1 < len(issued) else len(actual)
        version_seen = first_matching((data["active_version"] == i) & valid[:, 0], begin, end)
        desired = direction(command)
        eligible = begin if version_seen is None else version_seen
        if command[1] == 0:
            def reached(v):
                return np.linalg.norm(v, axis=1) <= 0.12
        elif command[2] == 0:
            def reached(v):
                return v[:, 0] >= 0.24
        else:
            def reached(v):
                return (v[:, 1] * np.sign(desired[1]) >= 0.18) & ((v @ desired) / np.linalg.norm(desired) >= 0.24)
        ref_hit = first_matching(reached(ref_moving), eligible, end, 8) if version_seen is not None else None
        actual_hit = first_matching(reached(moving) & ~limits["fallen"], eligible, end, 8) if version_seen is not None else None
        record.append({"version": i, "time_s": float(data["t"][begin]), "speed_m_s": command[1],
                       "heading_deg": command[2], "arrived_ms": None if version_seen is None else 1000*float(wall[version_seen]-wall[begin]),
                       "ref_criterion_ms": None if ref_hit is None else 1000*float(wall[ref_hit] - wall[begin]),
                       "physics_criterion_ms": None if actual_hit is None else 1000*float(wall[actual_hit] - wall[begin])})
    missed = ~valid[:, 0]
    result = {"events": record, "future_missing_fraction": float(np.mean(~valid[:, 1:10])),
              "hold_ms": float(np.sum(missed) * DT * 1000), "max_hold_ms": longest(missed) * DT * 1000,
              "count_old_jobs_accepted": sum(row["phase"] == "accepted" and
                  row["version"] != int(data["command_version"][row["done_tick"]]) for row in meta["ledger"]),
              "stale_jobs_discarded": sum(row["phase"] == "stale_command" for row in meta["ledger"]),
              "late_jobs_discarded": sum(row["phase"] == "missed_splice" for row in meta["ledger"]),
              "blackout_drops": sum(row["phase"] == "blackout_drop" for row in meta["ledger"]),
              "commits": sum(row["phase"] == "accepted" for row in meta["ledger"]) + 1}
    splice = data["splice_25"]
    marks = []
    for tick in np.flatnonzero(splice >= 0):
        hit = np.flatnonzero((np.arange(len(actual)) >= tick) & (data["motion_tick"] >= 2 * splice[tick]))
        if len(hit):
            first = int(hit[0])
            # If this exact old plan had already been superseded at the boundary, it was never played.
            next_boundaries = (np.arange(len(actual)) > tick) & (np.arange(len(actual)) <= first)
            if not np.any((splice[next_boundaries] >= 0) & (splice[next_boundaries] <= splice[tick])):
                marks.append(first)
    # At 50 Hz, the odd/even pair is two halves of the same 25 Hz segment.
    # Compare source-cadence secants so that interpolation cannot mask a seam jump.
    q = data["preview"][:, 0]
    d = np.asarray([mark for mark in marks if mark >= 4 and mark + 2 < len(q)], dtype=int)
    before = q[d - 2, :3] - q[d - 4, :3]
    cross = q[d, :3] - q[d - 2, :3]
    after = q[d + 2, :3] - q[d, :3]
    vjump = np.maximum(np.linalg.norm(cross - before, axis=1), np.linalg.norm(after - cross, axis=1)) / (2 * DT)
    dot = np.abs(np.sum(q[d, 3:7] * q[d - 2, 3:7], axis=1))
    result["seam_translation_m"] = stats(np.linalg.norm(cross, axis=1))
    result["seam_root_velocity_jump_m_s"] = stats(vjump)
    result["seam_root_rotation_deg"] = stats(2 * np.degrees(np.arccos(np.clip(dot, 0, 1))))
    result["seam_max_joint_step_deg"] = stats(np.max(np.abs(np.degrees(q[d, 7:] - q[d - 2, 7:])), axis=1))
    if "blackout" in meta["trial"]:
        start, end = meta["trial"]["blackout"]
        post = first_matching(valid[:, 0], end, len(valid))
        horizon = first_matching(valid[:, :10].all(axis=1), end, len(valid))
        result.update(blackout_ms=(end - start)*DT*1000,
                      after_blackout_first_pose_ms=None if post is None else (post - end)*DT*1000,
                      after_blackout_full_preview_ms=None if horizon is None else (horizon - end)*DT*1000)
    if "wall_s" in data:
        result["host_tick_lateness_ms"] = stats(np.maximum(0, wall - data["t"]) * 1000)
    return result


def trial(sim, policy, feet, path, meta, variant):
    data, z_shift = load_50hz(path, sim, feet, variant)
    preview = data["preview"]
    q = preview[:, 0]
    if preview.shape[1:] != (SLOTS, 36) or not np.isfinite(preview).all():
        raise ValueError("Bad preview contract")
    n = len(q)
    velocity = np.empty((n, 10, sim.mj_model.nv), dtype=np.float64)
    for tick, poses in enumerate(preview):
        for i in range(10):
            mujoco.mj_differentiatePos(sim.mj_model, velocity[tick, i], DT, poses[i], poses[i + 1])
    assert np.max(np.abs(velocity[~data["valid"][:, 1:]]), initial=0.) < 1e-8
    observation = SonicObsBuilder({"qpos": preview[0, :10], "qvel": velocity[0]}, encoder_dim=SPEC.encoder_dim)
    sim.init_qpos = q[0].astype(np.float32).copy()
    sim.init_qpos[2] += z_shift
    state = sim.reset(sim.init_state())
    observation.reset(state.mj_data.qpos[3:7].copy())
    action = np.zeros(29, dtype=np.float32)
    actual = np.empty_like(q)
    fields = {name: [] for name in ["clearance", "reference_site", "ankle", "reference_bodies",
                                    "actual_site", "force", "slip", "actual_bodies", "control", "onnx", "time"]}
    for tick, poses in enumerate(preview):
        live = state.mj_data
        current = live.qpos.copy()
        actual[tick] = current
        fields["time"].append(float(live.time))
        for name, value in zip(("clearance", "reference_site", "ankle", "reference_bodies"), feet.reference(poses[0])):
            fields[name].append(value)
        height, force, slip, _, _, bodies = feet.actual_tick(live)
        for name, value in zip(("actual_site", "force", "slip", "actual_bodies"), (height, force, slip, bodies)):
            fields[name].append(value)
        start = time.perf_counter_ns()
        observation.ref_jpos_isab = poses[:10, 7:][:, ISAB_TO_MUJ]
        observation.ref_jvel_isab = velocity[tick, :, 6:][:, ISAB_TO_MUJ]
        observation.ref_root_quat = poses[:10, 3:7]
        gyro = get_sensor_data(sim.mj_model, live, "gyro_pelvis")
        observation.update_history(gyro, current[7:][ISAB_TO_MUJ] - DEFAULT_ANGLES_ISAB,
                                   live.qvel[6:][ISAB_TO_MUJ], action, current[3:7])
        packet = encoder_input(observation, SPEC, SPEC.offsets, current[3:7], last_visible=9, realtime=False)
        infer = time.perf_counter_ns()
        action = policy.eval_step(observation, packet)
        fields["onnx"].append((time.perf_counter_ns() - infer) / 1e6)
        state = sim.step(state, action_to_motor_targets(action))
        fields["control"].append((time.perf_counter_ns() - start) / 1e6)
    if not np.isfinite(actual).all() or not np.allclose(fields["time"], data["t"], atol=1e-7):
        raise ValueError("MuJoCo pre-step clock or state mismatch")
    trace = {key: np.asarray(value) for key, value in fields.items()}
    absolute_target = data["target"]
    err = np.linalg.norm(actual[:, :2] - q[:, :2], axis=1)
    path_error = np.linalg.norm(q[:, :2] - absolute_target, axis=1)
    planar_vel = finite_difference_speed(q[:, :2], 4)
    airborne_moving = (np.min(trace["clearance"], axis=1) > .02) & (np.linalg.norm(planar_vel, axis=1) >= .12)
    rotor_tilt = 1 - 2 * (actual[:, 4]**2 + actual[:, 5]**2)
    fallen = (actual[:, 2] < .45) | (rotor_tilt < .5)
    contact = np.max(trace["force"], axis=1) >= 10
    first_load = first_matching(contact, 0, n)
    dangle = (actual[:, 7:] - q[:, 7:] + np.pi) % (2 * np.pi) - np.pi
    results = {"kind": meta["kind"], "mode": meta["mode"], "variant": variant, "seed": meta["seed"],
               "paced": meta.get("paced", False), "source": path.stem, "frames": len(q),
               "root_path_mae_m": float(np.mean(path_error)), "sonic_reference_mae_m": float(np.mean(err)),
               "sonic_target_mae_m": float(np.mean(np.linalg.norm(actual[:, :2] - absolute_target, axis=1))),
               "joint_mae_deg": float(np.mean(np.abs(np.degrees(dangle)))),
               "heading_error_deg": float(np.mean(np.abs((yaw(actual) - yaw(q) + 180) % 360 - 180))),
               "fallen": bool(longest(fallen) >= 5), "lowest_actual_pelvis_m": float(min(actual[:, 2])),
               "arm_median_pose_delta_deg": float(np.degrees(np.median(np.abs(dangle[:, -14:])))),
               "first_load_ms": None if first_load is None else first_load * DT * 1000,
               "onnx_ms": stats(trace["onnx"]), "control_ms": stats(trace["control"]),
               "control_over_20ms": float(np.mean(trace["control"] > 20.0)),
               "actual_contact_ratio": float(np.mean(contact)),
               "foot_slip_m_s": stats(trace["slip"][np.isfinite(trace["slip"])]),
               "generation_ms": stats([r["wall_ms"] for r in meta["ledger"] if "wall_ms" in r]),
               "gpu_peak_MiB": meta.get("peak_allocated_MiB"), "z_shift": z_shift}
    for sec in (0.32, 2.0):
        lim = min(n - 1, round(sec / DT))
        j = slice(0, lim)
        label = "0_32s" if sec < 1 else "2s"
        results[label] = {"lower_sole_median_m": float(np.median(np.min(trace["clearance"][j], axis=1))),
                          "ref_airborne_moving_ratio": float(np.mean(airborne_moving[j])),
                          "reference_dx_m": float(q[lim, 0] - q[0, 0]),
                          "actual_dx_m": float(actual[lim, 0] - actual[0, 0]),
                          "contact_ratio": float(np.mean(contact[j])),
                          "foot_slip_m_s": stats(trace["slip"][j][np.isfinite(trace["slip"][j])]),
                          "first_frame_sole_m": trace["clearance"][0].tolist(),
                          "max_ref_penetration_m": float(max(0., -np.min(trace["clearance"][j])))}
    if meta["kind"] == "buffer":
        limits = {"fallen": fallen}
        results.update(scenario=meta["scenario"], **scheduling(data, actual, meta, limits))
        for key in ("active_version", "command_version", "valid", "tail_ticks", "blocked", "motion_tick"):
            trace[key] = data[key]
    if "positions" in data:
        names = list(data["joint_names"])
        indexes = [names.index(f"{side}_ankle_roll_skel") for side in ("left", "right")]
        native_ankle = data["positions"][:, indexes, 1]
        e = trace["ankle"][::2] - native_ankle
        results.update(native_to_mj_ankle_height_mae_m=float(np.mean(np.abs(e))),
                       native_first_ankle_m=native_ankle[0].tolist(), mj_first_ankle_m=trace["ankle"][0].tolist(),
                       first_knee_angles_rad=q[0, [10, 16]].tolist())
        trace["native_ankle_m"] = native_ankle
    names = [mujoco.mj_id2name(sim.mj_model, mujoco.mjtObj.mjOBJ_BODY, i) or "" for i in range(sim.mj_model.nbody)]
    trace.update(qpos_actual=actual, qpos_reference=q, target=data["target"], body_names=np.asarray(names),
                 body_parents=sim.mj_model.body_parentid.copy(), airborne_moving=airborne_moving)
    return results, trace


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("neutral", "buffer", "startup"), required=True)
    parser.add_argument("--pattern", default="*")
    parser.add_argument("--threads", type=int, default=2)
    parser.add_argument("--max", type=int)
    args = parser.parse_args()
    sim = SonicMjSim(init_qpos=SONIC_DEFAULT_QPOS, headless=True, xml_path=str(XML))
    feet = Feet(sim.mj_model)
    if args.mode == "neutral":
        neutral = feet.neutral()
        json_out(ROOT / "grounded-qpos.json", neutral)
        print(json.dumps(neutral))
        return
    if abs(sim.mj_model.opt.timestep - .001) > 1e-9:
        raise RuntimeError("Expected physical timestep of 1 ms")
    for term in ("motion_joint_positions", "motion_joint_velocities", "motion_anchor_orientation"):
        if f"{term}_10frame_step1" not in (SPEC.directory / "observation_config.yaml").read_text():
            raise ValueError("Low-Latency G1 observation config mismatch")
    policy = Controller(SPEC, args.threads)
    selected = sorted((ROOT / "references").glob(args.pattern + ".npz"))
    candidates = []
    for path in selected:
        meta = json.loads(path.with_suffix(".json").read_text())
        if meta["kind"] == args.mode:
            candidates.append((path, meta))
    if not candidates:
        raise RuntimeError("No matching reference files")
    traces = ROOT / "traces"
    traces.mkdir(exist_ok=True)
    for path, meta in candidates[:args.max]:
        variants = ["generated"]
        if meta["mode"] in {"h52_cold", "published_h52"}:
            variants.extend(("reset_only", "reference_z", "reference_z_reset"))
        for variant in variants:
            name = path.stem + ("_" + variant if variant != "generated" else "")
            metrics_path = ROOT / "metrics" / (name + ".json")
            if metrics_path.exists():
                continue
            start = time.perf_counter()
            result, trace = trial(sim, policy, feet, path, meta, variant)
            result["run_wall_s"] = time.perf_counter() - start
            tmp = traces / (name + ".tmp.npz")
            np.savez_compressed(tmp, **trace)
            tmp.replace(traces / (name + ".npz"))
            json_out(metrics_path, result)
            print("REPLAY", name, json.dumps({"run_wall_s": result["run_wall_s"], "first_2s": result["2s"],
                                             "fallen": result["fallen"]}), flush=True)


if __name__ == "__main__":
    main()
