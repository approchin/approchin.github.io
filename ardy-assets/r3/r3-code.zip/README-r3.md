# ARDY 第三轮复跑

固定使用 G1 25 Hz 的官方 ARDY H52、4 帧 patch、52 帧路径前视和 SONIC G1 Low-Latency。随机种子、配置、故障注入和模型版本见 r3-config.json。推理分组使用路径指令，文本条件由第二轮单独验证。

## 运行顺序

1. 在 Colab 的 GPU 和 CPU 运行时各建目录 /content/ardy-r3，把压缩包中的代码放进去。GPU 使用 T4，运行 bash setup-gpu.sh。CPU 运行 bash setup-cpu.sh。
2. 在 CPU 运行 .venv/bin/python replay_r3.py --mode neutral，生成 grounded-qpos.json。把这个小文件复制到 GPU 的相同目录。
3. 在 GPU 使用 PYTHONPATH=/content/ardy-r3/official ARDY_SKIP_MOTION_CORRECTION=1 .venv/bin/python -u generate_r3.py smoke 检查数据契约。保持相同前缀，依次将 smoke 换成 buffer、starts、extra，生成 references 中的 NPZ 和逐窗 JSON。
4. 将 references 传到 CPU。分别执行 .venv/bin/python -u replay_r3.py --mode buffer 和 .venv/bin/python -u replay_r3.py --mode startup。输出 metrics 与 traces，随后执行 .venv/bin/python summarize_r3.py 汇总。
5. 将 [第一轮代表轨迹](https://approchin.github.io/assets/ardy/representative-trajectories.zip) 作为 prior-references.zip 放入 CPU 目录，执行 .venv/bin/python diagnose_published.py 复查旧样例。用 .venv/bin/python render_r3.py video-spec.json 按固定案例渲染视频。

短窗启动选项在前 16 个 25 Hz 帧使用 H8，之后保持 H52。两组各用原厂版本；SONIC 编码器和解码器使用配套的 Low-Latency 检查点。首次启动前模型加载及预热没有计入每窗推理延迟。

## 数据契约

- references 的 buffer NPZ 中，preview 为每个控制时刻可见的 11 × 36 位姿。前 10 项供 SONIC，最后 1 项只用于已交付数据的速度差分。valid 逐槽标出该时刻是否真的收到了参考，缺失槽保持末个已交付位姿。motion_tick 单调，以 50 Hz 帧为单位，欠载期间暂停。
- 原始 ARDY 座标 Y 向上、Z 向前、X 向左。MuJoCo 使用 XYZ=[ARDY Z, ARDY X, ARDY Y]。36 列按根 XYZ（米）、根 WXYZ 四元数、29 个弧度制关节角排列。35 列速度由 MuJoCo 计算。
- G1 四个预测接触通道依次为左踝、左趾、右踝、右趾。物理验证使用同一个世界平面的六个脚部胶囊和实际法向接触力，保持两类信号分开。
- 50 Hz 中点使用最短弧四元数插值；相邻 25 Hz 源位姿暂缺时不得计算穿越缓冲尾端的速度。仿真时刻使用 MuJoCo 预步进时间，步长为 1 ms。

## 三类时间

T4 生成、约束构造与转换用同步 CUDA 计时。主矩阵用实测生产时延驱动离散 50 Hz 缓冲，另有真实墙钟的异步生产和播放。SONIC 逐帧耗时是在 CPU 上的 ONNX 与 1 ms 物理子步实测，物理回放的控制频率按仿真时钟计算。
