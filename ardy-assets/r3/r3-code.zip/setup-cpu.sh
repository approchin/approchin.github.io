#!/usr/bin/env bash
set -euxo pipefail
cd /content/ardy-r3
export PIP_DISABLE_PIP_VERSION_CHECK=1
if ! command -v uv >/dev/null; then python3 -m pip install --quiet uv; fi
if ! test -x .venv/bin/python; then uv venv --python 3.12 .venv; fi
. .venv/bin/activate
git init -q humantracker
git -C humantracker fetch --depth=1 https://github.com/GalaxyGeneralRobotics/HumanTracker.git 492f128dc903d1c859d2ff535c549c149f9adda8
git -C humantracker checkout --detach FETCH_HEAD
uv pip install --index-url https://download.pytorch.org/whl/cpu torch==2.8.0
uv pip install numpy==1.26.4 scipy mujoco==4.0.1 onnxruntime==1.32.0 opencv-python-headless==4.11.0.86 pyyaml pandas==2.2.3 huggingface_hub==0.36.2
python - <<'PY'
from huggingface_hub import snapshot_download
snapshot_download('nvidia/GEAR-SONIC',revision='6733128a3d8a523b1418b06bca3cdf61c8b0987f',allow_patterns=['low_latency/model_encoder.onnx','low_latency/model_decoder.onnx','low_latency/observation_config.yaml'],local_dir='sonic')
PY
command -v ffmpeg
touch CPU_READY