"""Render paired reference/physics field evidence from real replay traces."""
import argparse
import json
from pathlib import Path
import subprocess

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
W, H = 1200, 710
INK, GRAY = (47, 43, 43), (105, 101, 98)
REF, ACT = (89, 135, 30), (162, 74, 132)
ORANGE = (18, 103, 215)


def label(img, text, x, y, size=.58, color=INK):
    cv2.putText(img, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, size, color, 1 if size < .72 else 2, cv2.LINE_AA)


def draw_skeleton(img, p, parents, x, y, scale, shift, color):
    for i, parent in enumerate(parents):
        if not parent:
            continue
        coords = [tuple(np.rint([x + (p[b, 0] - shift) * scale, y - p[b, 2] * scale]).astype(int))
                  for b in (i, int(parent))]
        if any(abs(v) > 10000 for point in coords for v in point):
            continue
        cv2.line(img, *coords, color, 3, cv2.LINE_AA)
        cv2.circle(img, coords[0], 3, color, -1, cv2.LINE_AA)


def project(img, trace, tick, index, title, result):
    x0, y0 = 36 + index * 600, 68
    label(img, title, x0, y0 + 22, .73)
    grounded = trace["clearance"][tick].min()
    load = trace["force"][tick].max()
    q = trace["qpos_reference"][tick]
    qa = trace["qpos_actual"][tick]
    xlim = max(np.max(trace["qpos_reference"][:, 0]), np.max(trace["qpos_actual"][:, 0]))
    shrink = max(82., min(124., 380. / max(1.25, xlim)))
    for i, (bodies, color, name, tracker) in enumerate([
        ("reference_bodies", REF, "ARDY reference", q), ("actual_bodies", ACT, "MuJoCo / SONIC", qa)
    ]):
        yf = y0 + 228 + i * 196
        cv2.line(img, (x0, yf), (x0 + 520, yf), (164, 160, 157), 1, cv2.LINE_AA)
        header_offset = 160 if i == 0 else 136
        label(img, name, x0, yf - header_offset, .48, color)
        shift = max(0., q[0] - 2.)
        draw_skeleton(img, trace[bodies][tick], trace["body_parents"], x0 + 98, yf, shrink, shift, color)
        label(img, f"root X {tracker[0]:.2f} m  |  pelvis Z {tracker[2]:.2f} m", x0, yf + 21, .49)
        if i == 0:
            text = f"lowest sole: {grounded*100:+.1f} cm"
            if trace["airborne_moving"][tick]:
                text += "  |  both feet clear, root moving"
            label(img, text, x0, yf + 43, .49, ORANGE if trace["airborne_moving"][tick] else GRAY)
        else:
            label(img, f"max foot normal force: {load:.0f} N", x0, yf + 43, .49, GRAY)
    if "valid" in trace:
        names = ["walk", "turn", "stop", "resume"]
        label(img, f"command #{trace['command_version'][tick]}  |  playing #{trace['active_version'][tick]}", x0, 553, .50)
        if not trace["valid"][tick, 0]:
            state = "EXHAUSTED - hold last received pose"
        elif trace["blocked"][tick]:
            state = "Producer interrupted - consume received prefix"
        else:
            state = "Streaming"
        label(img, state, x0, 577, .49, ORANGE if trace["blocked"][tick] else INK)
        xbar = x0
        for k, color in enumerate([REF if v else ORANGE for v in trace["valid"][tick, :10]]):
            cv2.rectangle(img, (xbar+18*k, 589), (xbar+18*k+14, 600), color, -1)
        label(img, "SONIC preview 0...180 ms", xbar + 191, 599, .45, GRAY)
    else:
        label(img, f"2 s median sole clearance: {100*result['2s']['lower_sole_median_m']:+.1f} cm", x0, 563, .49)
        label(img, f"2 s actual forward travel: {result['2s']['actual_dx_m']:+.2f} m", x0, 589, .49)


def pair(title, left, right, names, out, limit=None):
    traces = []
    metrics = []
    for name in (left, right):
        with np.load(ROOT / "traces" / (name + ".npz"), allow_pickle=False) as data:
            traces.append(dict(data))
        metrics.append(json.loads((ROOT / "metrics" / (name + ".json")).read_text()))
    n = min(len(t["time"]) for t in traces)
    if limit:
        n = min(n, int(limit * 50))
    dest = ROOT / "videos" / out
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(".tmp.mp4")
    proc = subprocess.Popen(["ffmpeg", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "bgr24",
                             "-s", f"{W}x{H}", "-r", "25", "-i", "pipe:0", "-an", "-c:v", "libx264",
                             "-threads", "2", "-preset", "fast", "-crf", "23", "-pix_fmt", "yuv420p",
                             "-movflags", "+faststart", str(tmp)], stdin=subprocess.PIPE)
    try:
        for tick in range(0, n, 2):
            frame = np.full((H, W, 3), (253, 252, 249), dtype=np.uint8)
            label(frame, title, 35, 45, 1.04)
            cv2.line(frame, (600, 70), (600, 622), (220, 218, 214), 1, cv2.LINE_AA)
            for i, (trace, metric, name) in enumerate(zip(traces, metrics, names)):
                project(frame, trace, tick, i, name, metric)
            cv2.line(frame, (36, 642), (1164, 642), (219, 216, 211), 3, cv2.LINE_AA)
            cv2.line(frame, (36, 642), (36 + int(tick/max(1, n-1)*1128), 642), INK, 3, cv2.LINE_AA)
            label(frame, f"{tick/50:5.2f} s   |   reference 25 Hz   |   control 50 Hz   |   MuJoCo 1 ms", 36, 678, .61)
            proc.stdin.write(frame.tobytes())
    finally:
        proc.stdin.close()
    if proc.wait():
        raise RuntimeError("Video encoder failed")
    tmp.replace(dest)
    print(dest.name, dest.stat().st_size)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("spec")
    args = parser.parse_args()
    for item in json.loads((ROOT / args.spec).read_text()):
        pair(**item)


if __name__ == "__main__":
    main()

