"""Aggregate paired-seed results without mixing scheduler and physics events."""
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
from buffer_r3 import stats
from replay_r3 import json_out

ROOT = Path(__file__).resolve().parent
METRICS = ROOT / "metrics"
REPORTS = ROOT / "reports"


def median(x):
    series = [i for i in x if i is not None]
    return float(np.median(series)) if series else None


def main():
    trials = [json.loads(p.read_text()) for p in sorted(METRICS.glob("*.json"))]
    if not trials:
        raise ValueError("No physical trials")
    report = {"trial_count": len(trials), "counts": defaultdict(int), "startup": {},
              "buffer": {}, "wall_trials": [], "trials": trials}
    startup = defaultdict(list)
    buffers = defaultdict(list)
    raw_window_ms = []
    raw_denoise_ms = []
    raw_decode_ms = []
    raw_condition_ms = []
    for r in trials:
        report["counts"][r["kind"]] += 1
        if r["kind"] == "startup":
            startup[r["mode"] if r["variant"] == "generated" else r["variant"]].append(r)
        elif r["source"].startswith("smoke_"):
            report["counts"]["smoke"] += 1
        elif r["paced"]:
            report["wall_trials"].append(r)
        else:
            buffers[(r["scenario"], r["mode"])].append(r)
    for p in sorted((ROOT/"references").glob("*.json")):
        if p.stem.startswith("smoke_"):
            continue
        meta = json.loads(p.read_text())
        for job in meta["ledger"]:
            if "wall_ms" in job:
                raw_window_ms.append(job["wall_ms"])
                raw_denoise_ms.append(job["denoise_ms"])
                raw_decode_ms.append(job["decode_ms"])
                raw_condition_ms.append(job["condition_ms"])
    report["t4_job_latency_ms"] = {key: stats(v) for key,v in {
        "all": raw_window_ms, "denoise": raw_denoise_ms, "decode": raw_decode_ms, "constraint_build": raw_condition_ms}.items()}
    for key, rows in startup.items():
        group = {"n": len(rows), "fall_count": sum(r["fallen"] for r in rows)}
        for k in ("lower_sole_median_m", "ref_airborne_moving_ratio", "actual_dx_m", "reference_dx_m", "contact_ratio",
                  "max_ref_penetration_m"):
            group[k] = median(r["2s"][k] for r in rows)
        for k in ("sonic_reference_mae_m","root_path_mae_m", "first_load_ms", "joint_mae_deg", "native_to_mj_ankle_height_mae_m"):
            group[k] = median(r.get(k) for r in rows)
        group["first_2s_slip_m_s"] = median(r["2s"]["foot_slip_m_s"]["p50"] for r in rows)
        group["case_2s_airborne"] = [[r["seed"], r["2s"]["ref_airborne_moving_ratio"]] for r in rows]
        report["startup"][key] = group
    for (scenario, mode), rows in buffers.items():
        group = {"n": len(rows), "falls": sum(r["fallen"] for r in rows)}
        for k in ("hold_ms", "max_hold_ms", "future_missing_fraction", "blackout_ms",
                  "after_blackout_first_pose_ms", "after_blackout_full_preview_ms",
                  "sonic_reference_mae_m", "root_path_mae_m", "sonic_target_mae_m",
                  "count_old_jobs_accepted", "stale_jobs_discarded", "late_jobs_discarded",
                  "blackout_drops", "commits", "control_over_20ms"):
            group[k + "_median"] = median(r.get(k) for r in rows)
        for k in ("seam_root_velocity_jump_m_s", "seam_root_rotation_deg", "seam_max_joint_step_deg",
                  "seam_translation_m", "onnx_ms", "control_ms", "generation_ms"):
            group[k + "_median_p95"] = median(r[k]["p95"] for r in rows)
        for num in range(len(rows[0]["events"])):
            e = [r["events"][num] for r in rows]
            item = {"n": len(e), "version": e[0]["version"], "at_s": e[0]["time_s"], "speed_m_s": e[0]["speed_m_s"],
                    "heading_deg": e[0]["heading_deg"]}
            for k in ("arrived_ms", "ref_criterion_ms", "physics_criterion_ms"):
                item[k] = stats([one[k] for one in e if one[k] is not None])
            group.setdefault("events", []).append(item)
        report["buffer"][scenario + "/" + mode] = group
    report["physics_latency"] = {k: median(r[k0][p0] for r in trials)
         for k,k0,p0 in (("median_onnx_p50_ms","onnx_ms","p50"),("median_onnx_p95_ms","onnx_ms","p95"),
                          ("median_control_p50_ms","control_ms","p50"),("median_control_p95_ms","control_ms","p95"))}
    report["physics_latency"]["median_control_over_20ms"] = median(r["control_over_20ms"] for r in trials)
    report["physics_latency"]["T4_peak_allocated_mib"] = max(r["gpu_peak_MiB"] or 0 for r in trials)
    json_out(REPORTS/"summary.json", report)
    columns = ["source", "scenario", "kind", "mode", "variant", "seed", "paced", "frames", "hold_ms",
               "max_hold_ms", "future_missing_fraction", "after_blackout_first_pose_ms",
               "after_blackout_full_preview_ms", "stale_jobs_discarded", "count_old_jobs_accepted",
               "late_jobs_discarded", "root_path_mae_m", "sonic_reference_mae_m", "sonic_target_mae_m",
               "joint_mae_deg", "heading_error_deg", "fallen", "lowest_actual_pelvis_m",
               "first_load_ms", "actual_dx_first_2s_m", "reference_dx_first_2s_m",
               "airborne_moving_first_2s", "sole_median_first_2s_m", "first_2s_contact_ratio",
               "t4_p50_ms", "t4_p95_ms", "control_p50_ms", "control_p95_ms", "control_over_20ms",
               "native_to_mj_ankle_height_mae_m", "run_wall_s"]
    with (REPORTS/"trials.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for r in trials:
            writer.writerow({**r, "actual_dx_first_2s_m": r["2s"]["actual_dx_m"],
                            "reference_dx_first_2s_m": r["2s"]["reference_dx_m"],
                            "airborne_moving_first_2s": r["2s"]["ref_airborne_moving_ratio"],
                            "sole_median_first_2s_m": r["2s"]["lower_sole_median_m"],
                            "first_2s_contact_ratio": r["2s"]["contact_ratio"],
                            "t4_p50_ms": r["generation_ms"]["p50"], "t4_p95_ms": r["generation_ms"]["p95"],
                            "control_p50_ms": r["control_ms"]["p50"], "control_p95_ms": r["control_ms"]["p95"]})
    with (REPORTS/"events.csv").open("w") as handle:
        writer=csv.DictWriter(handle, fieldnames=["case", "mode", "scenario", "seed", "paced", "version",
                             "time_s", "speed_m_s", "heading_deg", "arrived_ms",
                             "ref_criterion_ms", "physics_criterion_ms"])
        writer.writeheader()
        for r in trials:
            for e in r.get("events", []):
                writer.writerow({**e, "case": r["source"], **{k:r[k] for k in ("mode","scenario","seed","paced")}})
    small = {k:v for k,v in report.items() if k not in ("trials","wall_trials")}
    for key, val in small["buffer"].items():
        small["buffer"][key] = {k: v for k,v in val.items() if (k == "n" or k == "falls" or k == "events" or
                                k.startswith(("after_blackout", "max_hold", "future_missing", "sonic_reference", "stale_jobs")))}
    print(json.dumps(small))
    print("WALL", json.dumps([{k:v for k,v in r.items() if k in ("source","events","host_tick_lateness_ms","hold_ms",
                          "future_missing_fraction","after_blackout_full_preview_ms","stale_jobs_discarded")} for r in report["wall_trials"]]))


if __name__ == "__main__":
    main()
