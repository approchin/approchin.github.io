#!/usr/bin/env bash
set -euxo pipefail
cd /content/ardy-r3
export PIP_DISABLE_PIP_VERSION_CHECK=1
export HF_HUB_DISABLE_IMPLICIT_TOKEN=1
export ARDY_SKIP_MOTION_CORRECTION=1
if ! command -v uv >/dev/null; then python3 -m pip install --quiet uv; fi
uv venv --python 3.12 .venv
. .venv/bin/activate
git init -q official
git -C official fetch --depth=1 https://github.com/nv-tlabs/ardy.git e706e27acc88070918308a10922b8f7174d0825e
git -C official checkout --detach FETCH_HEAD
uv pip install --index-url https://download.pytorch.org/whl/cu126 torch==2.8.0 torchvision==0.23.0
uv pip install -e official 'numpy==1.26.4' 'mujoco==4.0.1' 'huggingface_hub>=1.0'
python - <<'PY'
import concurrent.futures
from huggingface_hub import snapshot_download
from pathlib import Path
models=[
 ('H52','nvidia/ARDY-G1-RP-25FPS-Horizon52','3d4c1ff16af4871b18125c95271e77c7f6f530d7'),
 ('H8','nvidia/ARDY-G1-RP-25FPS-Horizon8','fb815e8021d700af523ac32d9851b7e489fbb60b')]
def cache(spec):
 name, repo, rev=spec
 p=snapshot_download(repo, revision=rev, token=False, ignore_patterns=['.gitattributes','README.md','*.webm','*.mp4','*.gif','*.jpg','*.png'])
 Path(name+'.path').write_text(p)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: list(pool.map(cache,models))
PY
nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv
touch GPU_READY