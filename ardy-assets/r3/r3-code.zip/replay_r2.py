"""Replay timestamped ARDY references with official SONIC Low-Latency in MuJoCo."""
import argparse
import csv
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

import mujoco
import numpy as np

ROOT=Path('/content/ardy-r2')
sys.path.insert(0,str(ROOT/'humantracker/src'))
from previous_sonic_replay import Controller, SPECS, encoder_input, resample
from humantracker.eval.backends.sonic import (DEFAULT_ANGLES_ISAB, ISAB_TO_MUJ,
      SONIC_DEFAULT_QPOS, SonicMjSim, SonicObsBuilder, action_to_motor_targets)
from humantracker.eval.core.geometry import get_sensor_data
from render_r2 import kinematic_video, physics_video

XML=ROOT/'humantracker/storage/assets/unitree_g1_5010/scene_mjx_track_papergray.xml'
DRIVE=Path('/content/drive/MyDrive/语音控制动作生成/ardy/2026-11-23_第二轮文本与路径对照')


def percentiles(values):
    x=np.asarray(values,dtype=float)
    x=x[np.isfinite(x)]
    return None if not len(x) else dict(p50=float(np.median(x)),p95=float(np.percentile(x,95)),max=float(x.max()))


def series_window(x):
    return dict(first_window_mean=float(np.mean(x[:16])),after_first_to_2s_mean=float(np.mean(x[16:100])),
         min_first_2s=float(np.min(x[:100])),median_first_2s=float(np.median(x[:100])))


def wrapped(degrees):
    return (degrees+180)%360-180


def yaw(q):
    w,x,y,z=np.moveaxis(q[...,3:7],-1,0)
    return np.degrees(np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z)))


def checker(file, count=240):
    p=subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_name,nb_frames:format=duration',
                      '-of','json',str(file)],check=True,capture_output=True,text=True)
    data=json.loads(p.stdout)
    stream=data['streams'][0]
    if stream['codec_name']!='h264' or int(stream['nb_frames'])!=count:
        raise ValueError(f'Invalid H264 frame record for {file.name}')
    return data


def json_write(p,obj):
    tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
    tmp.replace(p)


def save_to_drive(path):
    if not DRIVE.is_dir():
        raise RuntimeError('Round-2 Drive directory is absent')
    target=DRIVE/path.relative_to(ROOT)
    target.parent.mkdir(exist_ok=True,parents=True)
    temp=target.with_suffix(target.suffix+'.copying')
    shutil.copyfile(path,temp)
    if temp.stat().st_size!=path.stat().st_size:
        raise IOError(f'Drive copy size mismatch: {path.name}')
    temp.replace(target)


class FootInstrumentation:
    def __init__(self, model):
        self.model=model
        self.probe=mujoco.MjData(model)
        self.ref=mujoco.MjData(model)
        self.sites=[mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_SITE,n) for n in ('left_foot','right_foot')]
        self.floor=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,'floor')
        if min(self.sites+[self.floor])<0:
            raise ValueError('Pinned foot-site or floor name unavailable')
        self.collisions={}
        for side,word in enumerate(('left','right')):
            parent=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_BODY,word+'_ankle_roll_link')
            for i in (1,2,3):
                geom=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,word+f'_foot{i}_collision')
                if geom<0 or model.geom_bodyid[geom]!=parent:
                    raise ValueError('Unexpected foot collision geom')
                self.collisions[geom]=side
        self.jac=np.empty((3,model.nv))
        self.wrench=np.zeros(6,dtype=np.float64)

    def copy_probe(self,actual):
        data=self.probe
        for field in ('qpos','qvel','qacc_warmstart','act','ctrl'):
            getattr(data,field)[:]=getattr(actual,field)
        data.time=actual.time
        mujoco.mj_forward(self.model,data)
        return data

    def ref_tick(self,q):
        self.ref.qpos[:]=q
        mujoco.mj_kinematics(self.model,self.ref)
        mujoco.mj_collision(self.model,self.ref)
        contact=np.zeros(2,dtype=bool)
        for c in self.ref.contact:
            a,b=c.geom
            other=b if a==self.floor else (a if b==self.floor else -1)
            if other in self.collisions and c.dist<=0:
                contact[self.collisions[other]]=True
        return self.ref.site_xpos[self.sites,2].copy(),contact,self.ref.xpos.copy()

    def actual_tick(self,actual):
        d=self.copy_probe(actual)
        force=np.zeros(2)
        weighted_speed=np.zeros(2)
        counts=np.zeros(2,dtype=np.int16)
        extra_floor=0
        for i,c in enumerate(d.contact):
            if c.efc_address<0:
                continue
            a,b=c.geom
            other=b if a==self.floor else (a if b==self.floor else -1)
            if other==-1:
                continue
            if other not in self.collisions:
                extra_floor+=1
                continue
            side=self.collisions[other]
            mujoco.mj_contactForce(self.model,d,i,self.wrench)
            load=max(0.,float(self.wrench[0]))
            force[side]+=load
            counts[side]+=1
            if load>0:
                body=int(self.model.geom_bodyid[other])
                mujoco.mj_jac(self.model,d,self.jac,None,c.pos,body)
                velocity=self.jac@d.qvel
                weighted_speed[side]+=load*np.linalg.norm(velocity[:2])
        speed=np.full(2,np.nan)
        np.divide(weighted_speed,force,out=speed,where=force>=10)
        return d.site_xpos[self.sites,2].copy(),force,speed,counts,extra_floor,d.xpos.copy()


def run_trial(sim,policy,instrument,path,init_shift_z=0.0):
    with np.load(path,allow_pickle=False) as input:
        q25=input['qpos']
        q,velocity=resample(q25,sim.mj_model)
        target=input['target_ardy_xz']
        ends=input['generated_block_ends_25']
        delivered=input['block_available_s']
        foot25=input['foot_contacts']
        first_wait=float(delivered[0])
    n=len(q)
    goal=np.empty((0,2))
    if len(target):
        goal25=target[:,[1,0]]-q25[:1,:2]
        goal=np.column_stack([np.interp(np.arange(n)/50,np.arange(len(q25))/25,k) for k in goal25.T])
    time50=np.arange(n)/50
    # Physics playhead starts once the first reference is emitted. Subsequent chunks
    # become visible on their measured ARDY+conversion completion times.
    ready=delivered-first_wait
    idx=np.searchsorted(ready,time50,side='right')-1
    if np.min(idx)<0:
        raise ValueError('Initial playback started without a reference')
    known=ends[idx]
    visible=np.minimum(n-1,2*(known-1))
    starvation=np.arange(n)>visible
    sims=[]
    fields={name:[] for name in ('ref_foot_height_m','ref_floor_contacts','actual_foot_height_m',
        'actual_foot_force_N','actual_foot_slip_mps','actual_foot_contacts','other_ground_contacts',
        'ref_bodies','actual_bodies','time_s')}
    onnx_ms=[]
    control_ms=[]
    future_missing=0
    future_slots=0
    sim.init_qpos=q[0].astype(np.float32)
    sim.init_qpos[2]+=init_shift_z
    state=sim.reset(sim.init_state())
    obs=SonicObsBuilder(dict(qpos=q,qvel=velocity),encoder_dim=policy.spec.encoder_dim)
    obs.reset(state.mj_data.qpos[3:7].copy())
    action=np.zeros(29,dtype=np.float32)
    for tick in range(n):
        active=state.mj_data
        current=active.qpos.copy()
        speed=active.qvel
        sims.append(current)
        fields['time_s'].append(float(active.time))
        rh,rc,rb=instrument.ref_tick(q[tick])
        ah,forces,slip,counts,other,actual_bodies=instrument.actual_tick(active)
        for key,value in zip(('ref_foot_height_m','ref_floor_contacts','ref_bodies',
          'actual_foot_height_m','actual_foot_force_N','actual_foot_slip_mps','actual_foot_contacts',
          'other_ground_contacts','actual_bodies'),(rh,rc,rb,ah,forces,slip,counts,other,actual_bodies)):
            fields[key].append(value)
        start=time.perf_counter_ns()
        gyro=get_sensor_data(sim.mj_model,active,'gyro_pelvis')
        obs.update_history(gyro,current[7:][ISAB_TO_MUJ]-DEFAULT_ANGLES_ISAB,speed[6:][ISAB_TO_MUJ],
                           action,current[3:7])
        want=tick+policy.spec.offsets
        valid=(want>tick)&(want<n)
        future_missing+=int(np.count_nonzero(valid&(want>visible[tick])))
        future_slots+=int(np.count_nonzero(valid))
        packed=encoder_input(obs,policy.spec,want,current[3:7],visible[tick],True)
        inference=time.perf_counter_ns()
        action=policy.eval_step(obs,packed)
        onnx_ms.append((time.perf_counter_ns()-inference)/1e6)
        state=sim.step(state,action_to_motor_targets(action))
        control_ms.append((time.perf_counter_ns()-start)/1e6)
    actual=np.stack(sims)
    if not np.isfinite(actual).all():
        raise RuntimeError('Non-finite MuJoCo state')
    trace={name:np.asarray(sample) for name,sample in fields.items()}
    if not np.allclose(trace['time_s'],time50,atol=1e-7):
        raise RuntimeError('MuJoCo pre-step clock differs from 50Hz reference')
    trace.update(reference_qpos=q,actual_qpos=actual,target_mj_xy=goal,
       reference_predicted_contacts=foot25[np.arange(n)//2],
       last_available_frame_50=visible,fed_current_frame_50=np.minimum(np.arange(n),visible),
       starvation=starvation,onnx_ms=np.asarray(onnx_ms),control_ms=np.asarray(control_ms),
       body_parents=np.asarray(sim.mj_model.body_parentid).copy())
    trace['body_parents'][trace['body_parents']==0]=-1
    stable=np.convolve((actual[:,2]<.35).astype(int),np.ones(5,dtype=int),mode='valid')>=5
    run=longest=0
    for x in starvation:
        run=run+1 if x else 0
        longest=max(run,longest)
    stats=dict(
       sonicsim_root_tracking_mae_m=float(np.linalg.norm(actual[:,:2]-q[:,:2],axis=1).mean()),
       actual_target_path_mae_m=None if not len(goal) else float(np.linalg.norm(actual[:,:2]-goal,axis=1).mean()),
       joint_mae_deg=float(np.abs(wrapped(np.degrees(actual[:,7:]-q[:,7:]))).mean()),
       root_heading_abs_mae_deg=float(np.abs(wrapped(yaw(actual)-yaw(q))).mean()),
       actual_slip_stance_mps=percentiles(trace['actual_foot_slip_mps']),
       reference_lower_foot_z_m=series_window(np.min(trace['ref_foot_height_m'],axis=1)),
       actual_lower_foot_z_m=series_window(np.min(trace['actual_foot_height_m'],axis=1)),
       actual_pelvis_z_m=series_window(actual[:,2]),reference_pelvis_z_m=series_window(q[:,2]),
       foot_forces_first_2s_N=percentiles(trace['actual_foot_force_N'][:100]),
       ref_ground_contact_fraction_first_2s=float(np.any(trace['ref_floor_contacts'][:100],axis=1).mean()),
       actual_loaded_contact_fraction_first_2s=float(np.any(trace['actual_foot_force_N'][:100]>=10,axis=1).mean()),
       other_ground_contact_frames=int(np.count_nonzero(trace['other_ground_contacts'])),
       fall_pelvis_below_035_5_ticks=bool(np.any(stable)),
       first_fall_time_s=None if not np.any(stable) else float(np.flatnonzero(stable)[0]/50),
       min_pelvis_z_m=float(np.min(actual[:,2])),future_reference_missing_fraction=future_missing/future_slots,
       current_reference_starved_fraction=float(starvation.mean()),longest_starvation_s=longest/50,
       initial_wait_for_reference_s=first_wait,physics_control_frames=n,
       onnx_compute_ms=percentiles(np.asarray(onnx_ms)[20:]),control_loop_compute_ms=percentiles(np.asarray(control_ms)[20:]),
       p_cycle_over_20ms=float(np.mean(np.asarray(control_ms)[20:]>20)),init_pelvis_shift_z_m=init_shift_z,
       first_ref_foot_heights_m=trace['ref_foot_height_m'][0].tolist(),
    )
    return trace,stats


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--group',choices=('a','text','voice'),required=True)
    args=parser.parse_args()
    out=ROOT/'results'
    out.mkdir(exist_ok=True)
    spec=SPECS[1]
    if spec.name!='low_latency' or spec.encoder_dim!=1247 or spec.stride!=1:
        raise RuntimeError('Pinned G1 Low-Latency definition unavailable')
    # Reuse the verified encoder data layout and the pinned HumanTracker MuJoCo backend.
    active_spec=type(spec)(spec.name,ROOT/'weights'/'sonic'/'low_latency',spec.encoder_dim,spec.anchor_start,spec.stride)
    policy=Controller(active_spec,2)
    sim=SonicMjSim(init_qpos=SONIC_DEFAULT_QPOS,headless=True,xml_path=str(XML))
    if not (sim.mj_model.nq==36 and sim.mj_model.nv==35 and sim.mj_model.nu==29
            and np.isclose(sim.mj_model.opt.timestep,.001)):
        raise ValueError('Unexpected G1 MuJoCo model')
    instrument=FootInstrumentation(sim.mj_model)
    root=ROOT/'references'
    patterns={'a':['A_path_only_*.npz'],'text':['B_text_only_*.npz','C_text_path_*.npz'],'voice':['voice_*.npz']}
    queue=sorted({p for pattern in patterns[args.group] for p in root.glob(pattern)})
    expected={'a':18,'text':36}.get(args.group)
    if not queue or (expected is not None and len(queue)!=expected):
        raise RuntimeError(f'Unexpected ready reference count for {args.group}: {len(queue)}')
    rows=[]
    manifest=[]
    for i,p in enumerate(queue):
        meta=json.loads(p.with_suffix('.json').read_text())
        if meta['uses_real_text_embedding']!=(args.group!='a'):
            raise ValueError('Reference text condition differs from group')
        stats_file=out/(p.stem+'.json')
        trace_file=out/(p.stem+'_sonic.npz')
        kine=ROOT/'videos'/(p.stem+'_kinematics.mp4')
        physical=ROOT/'videos'/(p.stem+'_sonic.mp4')
        if all(s.is_file() for s in (stats_file,trace_file,kine,physical)):
            row=json.loads(stats_file.read_text())
        else:
            trace,metrics=run_trial(sim,policy,instrument,p)
            np.savez_compressed(trace_file,**trace)
            with np.load(p,allow_pickle=False) as data:
                kinematic_video(data,meta,kine)
            physics_video(trace,meta,physical)
            videos=[checker(kine),checker(physical)]
            row={**meta,'sonic':metrics,'physical_video':physical.name,'kinematic_video':kine.name,
                 'video_checks':videos}
            json_write(stats_file,row)
        for file in (p,p.with_suffix('.json'),stats_file,trace_file,kine,physical):
            save_to_drive(file)
            manifest.append(dict(name=str(file.relative_to(ROOT)),bytes=file.stat().st_size))
        rows.append(row)
        json_write(ROOT/'reports'/f'{args.group}_partial_metrics.json',rows)
        print('R2_CASE_COMPLETE',args.group,i+1,len(queue),p.stem,
             round(row['sonic']['sonicsim_root_tracking_mae_m'],4),flush=True)

    report=ROOT/'reports'
    report.mkdir(exist_ok=True)
    max_initial=max(rows,key=lambda r:min(r['sonic']['first_ref_foot_heights_m']))
    offset=-max(0.,min(max_initial['sonic']['first_ref_foot_heights_m']))
    diagnostic={'candidate':max_initial['trial'],'init_shift_z_m':offset,
                'raw_first_foot_heights_m':max_initial['sonic']['first_ref_foot_heights_m'],
                'trigger_minimum_positive_clearance_m':.008}
    if offset<-.008:
        trial=root/max_initial['reference_file']
        trace,shift=run_trial(sim,policy,instrument,trial,offset)
        raw=max_initial['sonic']
        diagnostic.update(raw_metrics=raw,shifted_init_metrics=shift,reference_changed=False)
        np.savez_compressed(out/f'{args.group}_initial_height_diagnostic.npz',**trace)
        save_to_drive(out/f'{args.group}_initial_height_diagnostic.npz')
    json_write(report/f'{args.group}_height_diagnostic.json',diagnostic)
    score=['trial','condition','prompt_id','seed','uses_real_text_embedding','ardy_root_mae_m','sonic_root_tracking_mae_m',
           'target_path_mae_m','joint_mae_deg','heading_mae_deg','slip_p50_mps','min_pelvis_z_m','fell','future_missing',
           'starved_now','ardy_window_p50_ms','ardy_window_p95_ms','conversion_p50_ms','onnx_p50_ms','onnx_p95_ms',
           'loop_over_20ms','peak_cuda_mib','semantic_review_1_to_5','naturalness_review_1_to_5','physics_review_1_to_5']
    with (report/f'{args.group}_metrics.csv').open('w',newline='',encoding='utf-8') as handle:
        writer=csv.writer(handle);writer.writerow(score)
        for row in rows:
            s=row['sonic']
            writer.writerow([row['trial'],row['condition'],row['prompt_id'],row['seed'],row['uses_real_text_embedding'],
                row['root_path_mae_m'],s['sonicsim_root_tracking_mae_m'],s['actual_target_path_mae_m'],
                s['joint_mae_deg'],s['root_heading_abs_mae_deg'],None if s['actual_slip_stance_mps'] is None else s['actual_slip_stance_mps']['p50'],
                s['min_pelvis_z_m'],s['fall_pelvis_below_035_5_ticks'],s['future_reference_missing_fraction'],
                s['current_reference_starved_fraction'],row['ardy_window_ms']['p50'],row['ardy_window_ms']['p95'],
                row['conversion_ms']['p50'],s['onnx_compute_ms']['p50'],s['onnx_compute_ms']['p95'],
                s['p_cycle_over_20ms'],row['peak_cuda_allocated_mib'],None,None,None])
    failures=sorted(rows,key=lambda r:r['sonic']['sonicsim_root_tracking_mae_m'],reverse=True)
    failures=[{'trial':r['trial'],'root_tracking_mae_m':r['sonic']['sonicsim_root_tracking_mae_m'],
      'fall':r['sonic']['fall_pelvis_below_035_5_ticks'],'min_pelvis_z_m':r['sonic']['min_pelvis_z_m'],
      'video':r['physical_video']} for r in failures[:3]]
    json_write(report/f'{args.group}_failure_examples.json',failures)
    json_write(report/f'{args.group}_metrics.json',rows)
    json_write(report/f'{args.group}_drive_manifest.json',manifest)
    for suffix in ('height_diagnostic.json','metrics.csv','metrics.json','failure_examples.json','drive_manifest.json'):
        save_to_drive(report/f'{args.group}_{suffix}')
    (report/f'{args.group}_tracking_ready').touch()
    print('R2_TRACKING_READY',args.group,len(rows),'DRIVE_FILES',len(manifest),flush=True)


if __name__=='__main__':
    main()
