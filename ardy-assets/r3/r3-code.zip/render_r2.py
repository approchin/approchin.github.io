"""Fast evidence videos from generated joints and measured MuJoCo states."""
import subprocess
from pathlib import Path
import cv2
import numpy as np

WIDTH, HEIGHT = 868, 474
BLUE=(158,102,37)
ORANGE=(51,91,201)
GRAY=(128,135,131)
DARK=(43,49,46)
GRID=(230,236,233)
WHITE=(250,251,250)


def stamp(img,value,xy,size=.53,color=DARK,width=1):
    cv2.putText(img,str(value),xy,cv2.FONT_HERSHEY_SIMPLEX,size,color,width,cv2.LINE_AA)


def skeleton(img,joints,parents,center,origin,color,thick=2,scale=121):
    rel=joints-np.array([center[0],center[1],0.0])
    projected=np.column_stack((rel[:,0]*0.88-rel[:,1]*0.46,
      -rel[:,2]+0.16*rel[:,0]+0.20*rel[:,1]))
    coords=np.rint(projected*scale+np.asarray(origin)).astype(int)
    for i,parent in enumerate(parents):
        if parent<0 or parent==i or parent>=len(coords):
            continue
        p,q=coords[i],coords[parent]
        if np.linalg.norm(p-q)<1.5:
            continue
        cv2.line(img,tuple(p),tuple(q),color,thick,cv2.LINE_AA)
        cv2.circle(img,tuple(p),2,color,-1,cv2.LINE_AA)
    return coords


def plot_mapper(tracks):
    xy=np.concatenate([t for t in tracks if len(t)],axis=0)
    mid=(np.min(xy,axis=0)+np.max(xy,axis=0))/2
    span=np.maximum(np.ptp(xy,axis=0),np.array([.9,.9]))
    scale=min(325/span[0],274/span[1],90)
    def transform(x):
        return np.rint((x-mid)*[scale,-scale]+[641,249]).astype(int)
    return transform


def plot_tracks(img,transform,tracks):
    cv2.rectangle(img,(452,107),(834,396),GRID,1)
    for x in range(480,830,38):
        cv2.line(img,(x,108),(x,395),GRID,1)
    for y in range(126,397,38):
        cv2.line(img,(453,y),(833,y),GRID,1)
    for line,color,thickness in tracks:
        if not len(line):
            continue
        xy=transform(line)
        if len(xy)>1:
            cv2.polylines(img,[xy],False,color,thickness,cv2.LINE_AA)
        cv2.circle(img,tuple(xy[-1]),4,color,-1,cv2.LINE_AA)


def background(title,subtitle,t):
    image=np.full((HEIGHT,WIDTH,3),WHITE,dtype=np.uint8)
    stamp(image,title,(25,33),.72,DARK,2)
    stamp(image,subtitle,(25,65),.53)
    stamp(image,f'{t:05.2f} s',(768,32),.54)
    cv2.line(image,(24,82),(844,82),GRID,1)
    cv2.line(image,(433,101),(433,414),GRID,1)
    stamp(image,'Ground-plane position',(465,101),.46)
    stamp(image,'+X forward / +Y left',(466,418),.43)
    return image


def write_video(path, images, fps=25):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.stem+'.tmp.mp4')
    args=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','bgr24','-video_size',f'{WIDTH}x{HEIGHT}',
          '-framerate',str(fps),'-i','pipe:','-an','-c:v','libx264','-preset','veryfast','-crf','25',
          '-pix_fmt','yuv420p','-movflags','+faststart',str(temp)]
    with subprocess.Popen(args,stdin=subprocess.PIPE) as task:
        for image in images:
            task.stdin.write(image.tobytes())
        task.stdin.close()
        if task.wait():
            raise RuntimeError(f'FFmpeg failed on {path.name}')
    if temp.stat().st_size<4000:
        raise RuntimeError(f'Empty video {path.name}')
    temp.replace(path)
    return path


def kinematic_video(data,meta,path):
    qpos=np.asarray(data['qpos'])
    joints=np.asarray(data['posed_joints'])[:,:,[2,0,1]]
    parents=np.asarray(data['joint_parents'])
    goal=np.asarray(data['target_ardy_xz'])[:,[1,0]]
    transform=plot_mapper([goal,qpos[:,:2]])
    foot=np.asarray(data['foot_contacts'])
    mode='Path control only' if not meta['uses_real_text_embedding'] else meta['condition']
    def frames():
        for i,t in enumerate(data['timestamps_s']):
            img=background(f"ARDY G1 kinematics | {meta['prompt_id']} | {mode}",meta['prompt_reference'],t)
            stamp(img,'Generated 34-joint skeleton',(27,104),.47)
            cv2.line(img,(29,369),(404,369),GRID,2)
            skeleton(img,joints[i],parents,qpos[i,:2],(214,367),BLUE,2,140)
            plot_tracks(img,transform,[(goal,GRAY,1),(qpos[:i+1,:2],BLUE,2)])
            stamp(img,'Target in grey | ARDY in blue',(466,442),.46)
            touched='L' if foot[i,:2].any() else '-'
            touched+= 'R' if foot[i,2:].any() else '-'
            stamp(img,f'Predicted foot contacts  {touched:2s}   Root z {qpos[i,2]:.2f} m',(27,413),.46)
            yield img
    return write_video(path,frames())


def physics_video(trace,meta,path):
    ref,actual,goal=trace['reference_qpos'],trace['actual_qpos'],trace['target_mj_xy']
    p=trace['body_parents']
    pos_ref,pos_actual=trace['ref_bodies'],trace['actual_bodies']
    transform=plot_mapper([goal,ref[:,:2],actual[:,:2]])
    f=trace['actual_foot_force_N']
    mode='Path control only' if not meta['uses_real_text_embedding'] else meta['condition']
    def frames():
        for i in range(0,len(ref),2):
            t=trace['time_s'][i]
            img=background(f"SONIC G1 in MuJoCo | {meta['prompt_id']} | {mode}",meta['prompt_reference'],t)
            stamp(img,'ARDY reference / tracked physics',(27,104),.45)
            cv2.line(img,(29,369),(404,369),GRID,2)
            # Root-centered panes show pose; the synchronized plot shows absolute position.
            skeleton(img,pos_ref[i],p,ref[i,:2],(128,367),BLUE,2,134)
            skeleton(img,pos_actual[i],p,actual[i,:2],(302,367),ORANGE,2,134)
            stamp(img,'Reference',(92,390),.46,BLUE)
            stamp(img,'Actual',(278,390),.46,ORANGE)
            l,r=f[i]
            stamp(img,f'Foot load {l:.0f} / {r:.0f} N   Hold {int(trace["starvation"][i])}',(28,423),.46)
            plot_tracks(img,transform,[(goal,GRAY,1),(ref[:i+1,:2],BLUE,2),(actual[:i+1,:2],ORANGE,2)])
            e=float(np.linalg.norm(actual[i,:2]-ref[i,:2]))
            stamp(img,f'Reference blue | Actual orange | Error {e:.2f} m',(466,442),.43)
            yield img
    return write_video(path,frames())
